PLUGINS = []
ADDONS = []
HELP = {}
LOADED = {}
LIST = {}
VC_HELP = {}
